create view CONTRATO as
SELECT R.nombre revista, 
C.nombre periodista, 
C.sueldo * 0.79 sueldo, 
C.fecha_contrato contrato,
2024 - EXTRACT(YEAR FROM C.fecha_contrato) annos,
NVL((SELECT COUNT(*)
	FROM ARTICULO A
	WHERE A.contratado = C.dni AND A.revista = R.idrev), 0) AS articulos
FROM revista R
LEFT JOIN CONTRATADO C ON C.revista = R.idrev
/

